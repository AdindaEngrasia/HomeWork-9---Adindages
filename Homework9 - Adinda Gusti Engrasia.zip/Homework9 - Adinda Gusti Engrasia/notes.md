NOTES : 
1. PUT, DELETE, POST API
2. Pagination
3. Authorization & Authentication
4. Dokumentasi Swagger
5. Logging