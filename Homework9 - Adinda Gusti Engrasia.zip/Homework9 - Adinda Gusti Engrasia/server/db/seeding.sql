INSERT INTO actor (actor_id, first_name, last_name, last_update)
values  (201, 'Cillian', 'Murphy', '2013-03-22 14:43:50.61');

INSERT INTO actor (actor_id, first_name, last_name, last_update)
values (202, 'Tom', 'Holland', '2012-01-19 10:30:45.55');

INSERT INTO actor (actor_id, first_name, last_name, last_update)
values (203, 'Emma', 'Stone', '2015-03-20 14:45:50.53');

INSERT INTO actor (actor_id, first_name, last_name, last_update)
values (204, 'Scarlett', 'Johansson', '2017-02-13 15:43:44.40');

INSERT INTO actor (actor_id, first_name, last_name, last_update)
values (205, 'Chris', 'Evans', '2018-01-30 15:50:40.33');