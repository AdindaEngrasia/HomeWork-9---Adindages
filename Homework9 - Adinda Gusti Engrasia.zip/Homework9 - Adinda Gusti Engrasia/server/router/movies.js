const express = require("express");
const router = express.Router();
const pool = require("../config/db");
const { authorize } = require("../middlewares/auth");
const { error } = require("winston");

router.use(authorize);

router.get("/", async function (req, res, next) {
  const { page } = req.body;

  try {
    const result = await pool.query(
      `SELECT * from public.movies WHERE ${page}`
    );

    res.status(201).json({ message: "success", result });
  } catch (err) {
    next(err);
  }
});

router.post("/", function (req, res, next) {
  const { id, title, genre, year } = req.body;
  const { rows } = pool.query(
    `INSERT INTO public.movies (id, title, movies, genre)
    VALUES (${id}, ${title}, ${genre}, ${year};`,
    (err, result) => {
      if (err) {
        next(err);
      } else {
        res.status(201).json({ message: "success", rows });
      }
    }
  );
});

router.put("/:moviesId", function (req, res, next) {
  const { title } = req.body;
  const { moviesId } = req.params;

  const { rows } = pool.query(
    `UPDATE (id, title, movies, genre)
      VALUES (${title} WHERE id = '${moviesId}';`,
    (err, result) => {
      if (err) {
        next(err);
      } else {
        res.status(201).json({ message: "success", rows });
      }
    }
  );
});

router.delete("/moviesId", function (req, res, next) {
  const { moviesId } = req.params;
  const { rows } = pool.query(
    `DELETE (id, title, movies, genre)
        VALUES (${title} WHERE id = ${moviesId};`,
    (err, result) => {
      if (err) {
        next(err);
      } else {
        res.status(201).json({ message: "success", rows });
      }
    }
  );
});

module.exports = router;
