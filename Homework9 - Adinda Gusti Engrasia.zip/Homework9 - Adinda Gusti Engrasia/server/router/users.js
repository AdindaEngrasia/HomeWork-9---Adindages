const express = require("express");
const router = express.Router();
const pool = require("../config/db");
const { generateToken } = require("../helpers/jwt")
const { error } = require("winston");

router.get("/", function (req, res, next) {
  pool.query("SELECT * FROM public.users", (err, result) => {
    if (err) {
      next(err)
    } else {
      res.status(200).json(result);
    }
  });
});

router.post("/register", function (req, res, next) {
  pool.query(`INSERT INTO`, (err, result) => {
    if (err) {
      next(err)
    } else {
      res.status(200).json(result);
    }
  });
});

router.get("/login", function (req, res, next) {
  const { email, password } = req.body;
  pool.query(
    `SELECT * FROM public.users WHERE email = '${email}' AND password = '${password}'`,
    (err, result) => {
      if (err) {
        next(err)
      } else {
        const { email, password } = result.rows[0]
        const { generateUserToken } = generateToken({ email, password })
        res.status(200).json({ access_token = generateUserToken, result: result.rows[0] });
      }
    }
  );
});

module.exports = router;
