const { DB_USER, HOST, NAME, PASSWORD, PORT } = process.env;

const Pool = require("pg").Pool;
const pool = new Pool({
  user: DB_USER,
  host: HOST,
  database: NAME,
  password: PASSWORD,
  port: PORT,
});

module.exports = pool;
