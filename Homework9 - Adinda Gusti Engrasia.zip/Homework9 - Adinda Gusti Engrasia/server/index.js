const express = require("express");
const app = express();
const port = 3001;
const bodyParser = require("body-parser");
const { authenticate } = require("./middlewares/auth");
require("dotenv").config();

const usersRouter = require("./router/users");
const moviesRouter = require("./router/movies");

app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());

app.use("/users", usersRouter);
app.use("/movies", moviesRouter);
app.use(authenticate);

app.listen(port, () => {
  console.log(`Berjalan di port ${port}`);
});
